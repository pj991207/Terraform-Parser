<h2>module relation test</h2>
<h3> network information <h3 />
<hr />
<ul>
<li>cand1</li>
    <ul>
    <li>VPC</li>
        <ul>
            <li>10.1.0.0/18</li>
        </ul>
    <li>SUBNET</li>
        <ul>
            <li>10.1.0.0/22  &nbsp;&nbsp;&nbsp;&nbsp;warning!!!</li>
            <li>10.1.4.0/22  &nbsp;&nbsp;&nbsp;&nbsp;warning!!!</li>
        </ul>
    </ul>
</ul>


<ul>
<li>cand2</li>
    <ul>
    <li>VPC</li>
        <ul>
            <li>10.2.0.0/16 &nbsp;&nbsp;&nbsp;&nbsp;warning!!!</li>
        </ul>
    <li>SUBNET</li>
        <ul>
            <li>10.2.1.0/24</li>
            <li>10.2.66.0/24</li>
        </ul>
    </ul>
</ul>


<ul>
<li>cand3</li>
    <ul>
    <li>VPC</li>
        <ul>
            <li>10.3.0.0/18</li>
        </ul>
    <li>SUBNET</li>
        <ul>
            <li>10.3.0.0/26</li>
            <li>10.3.4.0/26</li>
        </ul>
    </ul>
</ul>


<ul>
<li>cand1</li>
    <ul>
    <li>VPC</li>
        <ul>
            <li>10.4.0.0/18</li>
        </ul>
    <li>SUBNET</li>
        <ul>
            <li>10.4.0.0/26</li>
            <li>10.4.4.0/26</li>
        </ul>
    </ul>
</ul>
